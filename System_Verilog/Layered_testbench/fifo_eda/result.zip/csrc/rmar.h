#ifndef _RMAR1_H_
#define _RMAR1_H_

#ifdef __cplusplus
extern "C" {
#endif

#include <stdlib.h>

#ifndef __DO_RMAHDR_
#include "rmar0.h"
#endif /*__DO_RMAHDR_*/

extern UP rmaFunctionRtlArray[];

#ifdef __cplusplus
}
#endif
#endif

